<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Znaki drogowe</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Poznaj znaki drogowe</h1>
        <h2>Znaki ostrzegawcze</h2>
    </header>
    <main>
        <section id="opis">
            <ul>
                <?php 
                $conn = mysqli_connect("localhost", "root", "", "ja_znaki");
                $query = "SELECT symbol, nazwa FROM baza_znakow ORDER BY RAND() LIMIT 8;";
                $result = mysqli_query($conn, $query);
                $symbole = [];

                while($row = mysqli_fetch_assoc($result)){
                    echo "<li>{$row['nazwa']}</li>";
                    $symbole[] = $row['symbol'];
                }
                
                ?>
            </ul>
        </section>
        <section id="znaki">
            <?php
                shuffle($symbole); 
                foreach($symbole as $symbol){
                    echo "<div>
                        <img src='./img/A/{$symbol}.svg' alt='{$symbol}'>
                        <h3>{$symbol}</h3>
                    </div>";
                }

            ?>
            
            
        </section>
    </main>
</body>
</html>