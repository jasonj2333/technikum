-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 20, 2025 at 01:42 PM
-- Wersja serwera: 10.4.32-MariaDB
-- Wersja PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ja_znaki`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `baza_znakow`
--

CREATE TABLE `baza_znakow` (
  `id` int(11) NOT NULL,
  `symbol` varchar(12) NOT NULL,
  `nazwa` varchar(512) NOT NULL,
  `opis` varchar(512) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `baza_znakow`
--

INSERT INTO `baza_znakow` (`id`, `symbol`, `nazwa`, `opis`) VALUES
(1, 'A-1', 'Niebezpieczny zakręt w prawo', 'Ostrzega o niebezpiecznym zakręcie w kierunku wskazanym na znaku. '),
(2, 'A-2', 'Niebezpieczny zakręt w lewo', 'Ostrzega o niebezpiecznym zakręcie w kierunku wskazanym na znaku. '),
(3, 'A-3', 'Niebezpieczne zakręty, pierwszy w prawo', 'Ostrzega o dwóch niebezpiecznych zakrętach, z których pierwszy jest w kierunku wskazanym na znaku, a drugi może być zarówno w lewo, jak i w prawo. Może występować z tabliczką T-4 lub T-5. '),
(4, 'A-4', 'Niebezpieczne zakręty, pierwszy w lewo', 'Ostrzega o dwóch niebezpiecznych zakrętach, z których pierwszy jest w kierunku wskazanym na znaku, a drugi może być zarówno w lewo, jak i w prawo. Może występować z tabliczką T-4 lub T-5.'),
(5, 'A-5', 'Skrzyżowanie dróg', 'Ostrzega o skrzyzowaniu dróg, na którym pierwszeństwo przejazdu nie jest określone znakami.'),
(6, 'A-6a', 'Skrzyżowanie z drogą podporządkowaną występującą po obu stronach ', 'Ostrzega o skrzyżowaniu z drogą podporządkowaną, występującą po obu stronach. Umieszczona pod znakiem tabliczka T-6b wskazuje układ dróg na skrzyżowaniu. Gruba linia na znakach i tabliczkach oznacza drogę z pierwszeństwem.'),
(7, 'A-6b', 'Skrzyżowanie z drogą podporządkowaną występującą po prawej stronie ', 'Ostrzega o skrzyżowaniu z drogą podporządkowaną, występującą po stronie prawej. Umieszczona pod znakiem tabliczka T-6b wskazuje układ dróg na skrzyżowaniu. Gruba linia na znakach i tabliczkach oznacza drogę z pierwszeństwem.'),
(8, 'A-6c', 'Skrzyżowanie z drogą podporządkowaną występującą po lewej stronie', 'Ostrzega o skrzyżowaniu z drogą podporządkowaną, występującą po stronie lewej. Umieszczona pod znakiem tabliczka T-6b wskazuje układ dróg na skrzyżowaniu. Gruba linia na znakach i tabliczkach oznacza drogę z pierwszeństwem.'),
(9, 'A-6c', 'Skrzyżowanie z drogą podporządkowaną występującą po lewej stronie	', 'Ostrzega o skrzyżowaniu z drogą podporządkowaną, występującą po stronie lewej. Umieszczona pod znakiem tabliczka T-6b wskazuje układ dróg na skrzyżowaniu. Gruba linia na znakach i tabliczkach oznacza drogę z pierwszeństwem.'),
(10, 'A-6d', 'Wlot drogi jednokierunkowej z prawej strony	', 'Ostrzega o skrzyżowaniu z jednokierunkową drogą podporządkowaną, której wlot występuje po stronie prawej. Gruba linia na znakach oznacza drogę z pierwszeństwem.'),
(11, 'A-6e', 'Wlot drogi jednokierunkowej z lewej strony	', 'Ostrzega o skrzyżowaniu z jednokierunkową drogą podporządkowaną, której wlot występuje po stronie lewej. Gruba linia na znakach oznacza drogę z pierwszeństwem.'),
(12, 'A-7', 'Ustąp pierwszeństwa	', 'Ostrzega o skrzyżowaniu z drogą z pierwszeństwem. Znak A-7 znajdujący się w obrębie skrzyżowania dotyczy tylko najbliższej jezdni, przed którą został umieszczony. Przepis stosuje się odpowiednio do znaku A-7 umieszczonego przed torowiskiem pojazdów szynowych lub w innych miejscach przecinania się kierunków ruchu. Umieszczona pod znakiem A-7 tabliczka T-6c lub T-6d wskazuje rzeczywisty przebieg drogi z pierwszeństwem przez skrzyżowanie. Gruba linia na tabliczkach oznacza drogę z pierwszeństwem.'),
(13, 'A-8', 'Skrzyżowanie o ruchu okrężnym	', 'Ostrzega o skrzyżowaniu, na którym ruch odbywa się dookoła wyspy lub placu w kierunku wskazanym na znaku.'),
(14, 'A-9', 'Przejazd kolejowy z zaporami	', 'Ostrzega o przejeździe kolejowym wyposażonym w zapory lub półzapory. Umieszczona pod znakiem A-9 tabliczka T-7 wskazuje układ torów i drogi na przejeździe.'),
(15, 'A-10', 'Przejazd kolejowy bez zapór	', 'Ostrzega o przejeździe kolejowym niewyposażonym ani w zapory, ani w półzapory. Umieszczona pod znakiem A-10 tabliczka T-7 wskazuje układ torów i drogi na przejeździe.'),
(16, 'A-11', 'Nierówna droga	', 'Ostrzega o poprzecznej nierówności jezdni'),
(17, 'A-11a', 'Próg zwalniający	', 'Ostrzega o wypukłości na jezdni zastosowanej w celu spowolnienia ruchu pojazdów'),
(18, 'A-12a', 'Zwężenie jezdni - dwustronne	', 'Ostrzega o występującym po obu stronach jezdni zwężeniu, które może powodować utrudnienia ruchu'),
(19, 'A-12b', 'Zwężenie jezdni - prawostronne	', 'Ostrzega o występującym po prawej stronie jezdni zwężeniu, które może powodować utrudnienia ruchu'),
(20, 'A-12c', 'Zwężenie jezdni - lewostronne	', 'Ostrzega o występującym po lewej stronie jezdni zwężeniu, które może powodować utrudnienia ruchu'),
(21, 'A-13', 'Ruchomy most	', 'Ostrzega o wjeździe na most zwodzony lub obrotowy'),
(22, 'A-14', 'Roboty drogowe	', 'Ostrzega o prowadzonych na drodze robotach umieszczona pod znakiem tabliczka T-19 wskazuje na malowanie znaków poziomych'),
(23, 'A-15', 'Śliska jezdnia	', 'Ostrzega o możliwości poślizgu pojazdu spowodowanego w szczególności zmianą nawierzchni jezdni, stałym lub okresowym jej zawilgoceniem itd.'),
(24, 'A-16', 'Przejście dla pieszych	', 'Ostrzega o przejściu dla pieszych'),
(25, 'A-17', 'Dzieci', 'Ostrzega o miejscu na drodze szczególnie uczęszczanym przez dzieci lub o bliskości takiego miejsca.'),
(26, 'A-18a', 'Zwierzęta gospodarskie	', 'Ostrzega o możliwości napotkania na drodze zwierząt gospodarskich'),
(27, 'A-18b', 'Zwierzęta dzikie	', 'Ostrzega o możliwości napotkania na drodze zwierząt dzikich'),
(28, 'A-19', 'Boczny wiatr	', 'Ostrzega o miejscu, w którym mogą występować silne boczne podmuchy wiatru.'),
(29, 'A-20', 'Odcinek jezdni o ruchu dwukierunkowym	', 'Ostrzega jadących jezdnią jednokierunkową o miejscu, w którym rozpoczyna się ruch dwukierunkowy'),
(30, 'A-21', 'Tramwaj', 'Ostrzega o przejeździe przez tory tramwajowe. Umieszczona pod znakiem tabliczka T-7 wskazuje układ torów i drogi na tym przejeździe'),
(31, 'A-22', 'Niebezpieczny zjazd	', 'Ostrzega o znacznym spadku podłużnym drogi. Umieszczona pod znakiem tabliczka T-9 wskazuje rzeczywistą wielkość spadku, np. wartość 8% oznacza, że droga na długości 100m opada o 8 m.'),
(32, 'A-23', 'Stromy podjazd	', 'Ostrzega o znacznym wzniesieniu drogi. Umieszczona pod znakiem tabliczka T-9 wskazuje rzeczywistą wielkość wzniesienia, np. wartość 8% oznacza, że droga na długości 100m wznosi się o 8 m.'),
(33, 'A-24', 'Rowerzyści', 'Ostrzega o miejscu, w którym rowerzyści wjeżdżają z drogi dla rowerów na jezdnię lub przez nią przejeżdżają.'),
(34, 'A-25', 'Spadające odłamki skalne	', 'Ostrzega o możliwości spadania na drogę lub zalegania na niej odłamków skalnych o znacznej wielkości.'),
(35, 'A-26', 'Lotnisko', 'Ostrzega o możliwości nagłego pojawienia się nisko przelatującego samolotu lub śmigłowca'),
(36, 'A-27', 'Nabrzeże lub brzeg rzeki	', 'Ostrzega o odcinku drogi prowadzącym bezpośrednio do nabrzeża lub wzdłuż brzegu rzeki lub innego zbiornika wodnego'),
(37, 'A-28', 'Sypki żwir	', 'Ostrzega o odcinku drogi pokrytej żwirem (grysem), który może być wyrzucany spod kół jadących pojazdów'),
(38, 'A-29', 'Sygnały świetlne	', 'Ostrzega o miejscu, w którym ruch jest kierowany za pomocą sygnalizacji świetlnej'),
(39, 'A-30', 'Inne niebezpieczeństwo	', 'Ostrzega o niebezpieczeństwie innego rodzaju niż określone pozostałymi znakami ostrzegawczymi.'),
(40, 'A-31', 'Niebezpieczne pobocze	', 'Ostrzega o niebezpiecznym poboczu (miękkim lub obniżonym) znak z odwróconym symbolem ostrzega o niebezpiecznym poboczu występującym po lewej stronie drog'),
(41, 'A-32', 'Oszronienie jezdni	', 'Ostrzega o mogącym występować na drodze oszronieniu jezdni lub gołoledzi'),
(42, 'A-33', 'Zator drogowy	', 'Oostrzega o częstym występowaniu zablokowania ruchu pojazdów.'),
(43, 'A-34', 'Wypadek drogowy	', 'Ostrzega o miejscu, w którym na skutek wypadku drogowego nastąpiło zablokowanie drogi lub znaczne utrudnienie ruchu pojazdów.');

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `baza_znakow`
--
ALTER TABLE `baza_znakow`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `baza_znakow`
--
ALTER TABLE `baza_znakow`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
