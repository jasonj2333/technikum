<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Znaki drogowe</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Poznaj znaki drogowe</h1>
        <h2>Znaki ostrzegawcze</h2>
    </header>
    <main>
        <section id="opis">
            <ul>
                <form method="post" action="sprawdz.php">
                <?php 
                $conn = mysqli_connect("localhost", "root", "", "ja_znaki");
                $query = "SELECT id, symbol, nazwa FROM baza_znakow ORDER BY RAND() LIMIT 8;";
                $result = mysqli_query($conn, $query);
                $nazwy = [];
                $symbole = [];
                $ids = [];

                while($row = mysqli_fetch_assoc($result)){
                    //echo "<li>{$row['nazwa']}</li>";
                    $nazwy [] = $row['nazwa'];
                    $symbole[] = $row['symbol'];
                    $ids[] = $row['id'];
                }
                shuffle($symbole); 
                foreach($nazwy as $key=>$nazwa){
                    echo "<li>{$nazwa}";
                    echo "<select name='{$ids[$key]}'>";
                    echo "<option>---</option>";
                    foreach($symbole as $symbol){
                        echo "<option>$symbol</option>";
                    }
                    echo "</select>";
                    echo "</li>";
                }
                
                ?>
                <button>Sprawdź</button>
                </form>
            </ul>
        </section>
        <section id="znaki">
            <?php
                
                foreach($symbole as $symbol){
                    echo "<div>
                        <img src='./img/A/{$symbol}.svg' alt='{$symbol}'>
                        <h3>{$symbol}</h3>
                    </div>";
                }

            ?>
            
            
        </section>
    </main>
</body>
</html>