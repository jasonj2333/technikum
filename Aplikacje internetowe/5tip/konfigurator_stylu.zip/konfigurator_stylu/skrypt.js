const prawy = document.querySelector("#prawy19");

function zmienTlo(kolor){
    //console.log(prawy);
    prawy.style.backgroundColor = kolor;
}

function zmienKolorTekstu(kolor){
    prawy.style.color = kolor;
}

function zmienWielkoscTekstu(rozmiar){
    prawy.style.fontSize = rozmiar + "%";
}

function ramka(szerokosc = 1){
   const obrazek = document.querySelector("#gibraltar");
   const zaznaczenie = document.querySelector("#borderCheck");
   
   if(zaznaczenie.checked){
        obrazek.style.border = szerokosc + "px solid red";
   }else{
        obrazek.style.border = "none";
        document.querySelector("#borderWidth").value = 1;
   }
}

function ramkaSzerokosc(szerokosc){
    if(document.querySelector("#borderCheck").checked){
        ramka(szerokosc);
    }else{
        alert("Najpierw zaznacz rysuj ramkę!!");
        document.querySelector("#borderWidth").value = 1;
    }
    
}

function puktator(typ){
    const lista = document.querySelector("#lista");
    lista.style = "list-style-type:" + typ;
}