#import pgzrun

TITLE = "Pong 2024"
WIDTH = 900
HEIGHT = 500

player1 = Actor('player', (10, HEIGHT / 2))
player2 = Actor('player', (WIDTH - 10, HEIGHT / 2))
ball = Actor('ball', (WIDTH / 2, HEIGHT / 2))

ball_speed_x = 4
ball_speed_y = 4

def draw():
    screen.clear()
    player1.draw()
    player2.draw()
    ball.draw()
    
def update():
    global ball_speed_y
    global ball_speed_x
    ball.x += ball_speed_x
    ball.y += ball_speed_y
    
    #ball
    if ball.y > HEIGHT or ball.y < 0:
        ball_speed_y *= -1
    if ball.x > WIDTH or ball.x < 0:
        ball_speed_x *= -1
        
    #player1
    if keyboard.w and player1.top > 0:
        player1.y -= 5
    if keyboard.s and player1.bottom < HEIGHT:
        player1.y += 5
        
    #player1
    if keyboard.up and player2.top > 0:
        player2.y -= 5
    if keyboard.down and player2.bottom < HEIGHT:
        player2.y += 5

#pgzrun.go()