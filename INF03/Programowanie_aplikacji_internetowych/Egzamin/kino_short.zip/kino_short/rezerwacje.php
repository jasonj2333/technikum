<html>
<head>
<meta charset="utf-8">  
<title>KINO "Za rogiem"</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>



<section id="kontener">  

 <section id="baner">
  <img src="baner.jpg" alt="baner">   
  </section>  

 <section id="menu">
	<ul id="przyciski">
			<li> <a href="index.html"> Strona główna </a></li>		
	</ul>
	
<hr>
 <form action='rezerwacje.php'>
Data i godzina seansu <br>
<input type = 'date' name='dzien'>
<input type='time' name='czas'>
<input type='submit' value='Pokaż'>

</form>
 </section>

<section id="prawy">

</section>   

 
 <section id="stopka">
	<h5>Egzamin INF.03 - AUTOR: 00000000000</h5>
 </section>
 
</section>
</body>

</html>  