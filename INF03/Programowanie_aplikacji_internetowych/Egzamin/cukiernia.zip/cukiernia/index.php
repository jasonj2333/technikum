<!DOCTYPE html>
<html lang="pl-pl">
<head>
    <meta charset="UTF-8">
    <title>Cukiernia Różana</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Cukiernia Różana</h1>
        
    </header>
    <main>
        <aside>
            <h1>Nasze wyroby:</h1>
            <ul>
            <!-- Skrypt 1 -->

            </ul>
            
        </aside>
        <article>
            
            <div id="wybierz-cukiernie">
                <h1>Witaj!</h1>
                <!-- Skrypt 2 -->

                <h3>Wybierz cukiernię, aby wyświetlić, jakie mamy produkty!</h3>
                <form action="" method="post">
                    <!-- Skrypt 3 -->

                    </select>
                    <button type="submit">Ustaw cukiernię!</button>
                </form>
            </div>
            <div id="wyroby">
                <h2>Zobacz nasze ciasta!</h2>
                <img src="espinosa.jpg" alt="Ciasto espinosa">
                <img src="truskawkowa.jpg" alt="Truskawkowe szaleństwo">
                <img src="jezyny.jpg" alt="Jeżyny">
            </div>
        </article>
    </main>
    <footer>
        <p id="autor">Wykonał: 122321434124</p>
    </footer>
</body>
</html>