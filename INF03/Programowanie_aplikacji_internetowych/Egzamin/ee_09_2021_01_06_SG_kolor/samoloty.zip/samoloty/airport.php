<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Odloty samolotów</title>
    <link rel="stylesheet" href="styl6.css">
</head>
<body>
	<header>
		<div id="baner1"><h2>Odloty z lotniska</h2></div>
    	<div id="baner2"><img src="zad6.png" alt="logotyp"></div>
	</header>
	
    <main id="glowny">
        <table>
            <tr>
                <th>LP.</th>
                <th>NUMER REJSU</th>
                <th>CZAS</th>
                <th>KIERUNEK</th>
                <th>STATUS</th>
            </tr>
			
        </table>
	</main>
	<footer>
		<div id="stopka1">
		<a href="kw1.jpg">Pobierz obraz</a>
		</div>
		<div id="stopka2"><p>
			
			</p></div>
		<div id="stopka3">Autor:000000000</div>
	</footer>
    
</body>
</html>