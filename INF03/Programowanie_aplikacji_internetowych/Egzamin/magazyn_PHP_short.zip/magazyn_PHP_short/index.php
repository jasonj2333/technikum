<!DOCTYPE html>
<html lang="pl-pl">
<head>
    <meta charset="UTF-8">
    <title>Magazyn "Jaskółka" - panel administratora</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>Panel administratora magazynu Jaskółka</header>
    <main>
        <section id="lewy">
            <p>
                <b>Pracownicy dostępni dzisiaj: </b>
            </p>
            <ol>
                <!-- Skrypt 1 -->
            </ol>
        </section>
        <section id="prawy">
            <h2>Zestawienie produktów gotowych - magazyn ZH1</h2>
            <table>
                <tr>
                    <th>Nazwa towaru</th>
                    <th>Ilość towaru w produkcji</th>
                    <th>Ilość towarów uszkodzonych</th>
                    <th>Ilość towarów gotowych</th>
                </tr>

                <!-- Skrypt 2 -->

            </table>
            <form action="index.php" method="post">
                <label>Nazwa towaru: </label>
                <input type="text" name="nazwa">
                <br><br>
                <label>Ilośc gotowych towarów: </label>
                <input type="number" name="gotowe">
                <br><br>
                <label>Ilość towarów uszkodzonych: </label>
                <input type="number" name="uszkodzone">
                <br><br>
                <label>Ilość towarów w produkcji: </label>
                <input type="number" name="produkcja">
                <br><br>
                <button type="submit">Wyślij</button>
            </form>

            <!-- Skrypt 3 -->
            
        </section>
    </main>
    <footer>   
    Zdał egzamin: 1234JD
    </footer>
</body>
</html>