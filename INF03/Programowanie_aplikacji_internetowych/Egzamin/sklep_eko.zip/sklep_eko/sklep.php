<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Warzywniak</title>
    <link rel="stylesheet" href="styl2.css">
</head>
<body>
    <div class="banerL">
        <h1>Internetowy sklep z eko-warzywami</h1>
    </div>
    <div class="banerP">
        <ol>
            <li>Warzwa</li>
            <li>Owoce</li>
            <li><a href="https://terapiasokami.pl/" target="_blank">Soki</a></li>
        </ol>
    </div>
    <div class="glowny">
        <!--sktypt1-->
        <div class="gen">
            <img src="gruszka.jpg" alt="warzywniak">
            <p>opis: Klaps</p>
            <p>na stanie: 20</p>
            <h2>2.56zł</h2>
        </div>
        
    </div>
    <div class="stopka">
        <form action="" method="post">
            Nazwa: <input type="text" name="nazwa" id="nazwa">
            Cena: <input type="number" name="cena" id="cena">
            <input type="submit" value="Dodaj produkt"><br>
            Stronę wykonał: 1234567890
        </form>
        <!--sktypt2-->
        
    </div>
</body>
</html>