window.onload = function(){
    const cars = document.querySelectorAll('.samochody');
    const MainImage = document.querySelector('#image img');
    const MainUl = document.querySelector('#lista2');
    const people = document.querySelectorAll('.people');
    const ordersList = document.querySelector('#ordersList');
    
    cars.forEach(car => {
        car.addEventListener("click", ()=>{
            carSrc = car.children[0].src;
            carName = car.children[1].textContent;
            MainImage.src = carSrc;
            MainUl.innerHTML = "<li>" + carName + "</li>";
            ordersList.style.display = 'none';
        })
    });

    people.forEach(person => {
        person.addEventListener("click", ()=>{
            console.dir(person);
            personSrc = person.children[0].src;
            personName = person.children[1].textContent;
            MainImage.src = personSrc;
            MainUl.innerHTML = "<li>" + personName + "</li>";

            orders = document.querySelectorAll('.orders');
            orders.forEach(order => {
                order.style.display = 'none';
            })

            POclass = '.personOrders' + person.id
            console.log(POclass);
            personOrders = document.querySelectorAll(POclass);
            console.dir(personOrders);
            ordersList.style.display = 'block';
            personOrders.forEach(order => {
                order.style.display = 'block';
            })
        })
    });
};