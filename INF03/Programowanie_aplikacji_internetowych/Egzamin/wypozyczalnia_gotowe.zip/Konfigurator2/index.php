<!DOCTYPE html>
<html lang="pl-PL">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Wypożyczalnia samochodów</title>
	
    <link rel="stylesheet" href="styl6.css">
</head>

<body>
    <header>
        <h1>Wypożyczalnia samochodów</h1>
    </header>
    <main class="wrapper" id="wrapper">
        <div class="left" id="left">
            <h2>Wybierz samochód</h2>
            <?php
            require_once "connect.php";
            $conn = new mysqli($host, $user, $pass, $db);
            $q = "SELECT * FROM samochody";
            $result = mysqli_query($conn, $q);
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<article class='samochody'>";
                $car = $row['marka'] .'-'. $row['model'];
                echo '<img src="./img/'. $car .'.jpg" alt="'.$car.'" class="samochod">';
                echo '<p>'.$row['marka'].' ' . $row['model'] .' ' . $row['rocznik'] . '</p>';
                echo "</article>";
            }
            ?>
        </div>
        <div class="mid" id="mid">
            <section id="image">
                <img src="./img/wypozyczalnia.jpg" alt="Wypożyczalnia samochodów" id="img">
            </section>
            <ul id="lista2">
                <li>Najlepsze samochody</li>
                <li>Atrakcyjne ceny</li>
                <li>Atrakcyjne warunki wypożyczenia</li>
            </ul>
            <div id="ordersList">
                    <h3>Lista wypożyczeń:</h3>
                    <?php
                        $q = "SELECT s.marka, s.model, k.id, w.data, w.ilosc_dni  FROM wypozyczenia w INNER JOIN klienci k ON w.klienci_id = k.id INNER JOIN samochody s ON w.samochody_id = s.id ORDER BY s.id;";
                        $result = mysqli_query($conn, $q);
                        while ($row = mysqli_fetch_assoc($result)) { 
                            $order = $row['marka'] .' '. $row['model'].' | Data wypożyczenia'. $row['data'].' | dni: '. $row['ilosc_dni'];
                            echo '<p class="orders personOrders'.$row['id'].'">'.$order .'</p>';  
                        }
                    ?>
                
            </div>
            <hr style="clear:both">
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi
                ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa
                qui officia deserunt mollit anim id est laborum.</p>
        </div>
        <div id="right" class="right">
        <h2>Wybierz osobę</h2>
            <?php
            require_once "connect.php";
            $conn = new mysqli($host, $user, $pass, $db);
            $q = "SELECT * FROM klienci";
            $result = mysqli_query($conn, $q);
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<div class='people' id='".$row['id']."'>";
                $person = $row['imie'] .'-'. $row['nazwisko'];
                echo '<img src="./img/avatar.png" alt="'.$person.'" class="person">';
                echo '<p>'.$person .'</p>';
                echo "</div>";
            }

            
            ?>
        </div>    
    </main>

    <footer>
        Autor: 1123213213123122
    </footer>

    <script src="index.js" defer></script>
    </script>
</body>

</html>
