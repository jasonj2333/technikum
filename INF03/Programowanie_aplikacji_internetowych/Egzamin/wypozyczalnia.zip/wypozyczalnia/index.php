<!DOCTYPE html>
<html lang="pl-PL">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Wypożyczalnia samochodów</title>
	
    <link rel="stylesheet" href="styl6.css">
</head>

<body>
    <header>
        <h1>Wypożyczalnia samochodów</h1>
    </header>
    <main class="wrapper" id="wrapper">
        <div class="left" id="left">
            <h2>Wybierz samochód</h2>
            <!-- Skrypt PHP - wyświetlający samochody -->

        </div>
        <div class="mid" id="mid">
            <section id="image">
                <img src="./img/wypozyczalnia.jpg" alt="Wypożyczalnia samochodów" id="img">
            </section>
            <ul id="lista2">
                <li>Najlepsze samochody</li>
                <li>Atrakcyjne ceny</li>
                <li>Atrakcyjne warunki wypożyczenia</li>
            </ul>
            <div id="ordersList">
                <h3>Lista wypożyczeń:</h3>
                    <!-- Skrypt PHP - wyświetlający listę wypożyczeń - wszystkie z bazy -->

                    <!-- Jako zadanie dodatkowe - listę wypożyczeń tylko konretnego klienta - po klinięciu a klienta -->
                
            </div>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi
                ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa
                qui officia deserunt mollit anim id est laborum.</p>
        </div>
        <div id="right" class="right">
        <h2>Wybierz osobę</h2>
            <!-- Skrypt PHP - wyświetlający listę klientów -->

        </div>    
    </main>

    <footer>
        Autor: 1123213213123122
    </footer>

    </script>
</body>

</html>
