<?php 
    require_once 'dbconnect.php';
    $conn = new mysqli($server, $login, $pass, $db);

    if(isset($_POST['imie'])){
        $errors = [];
        $imie = $_POST['imie'];
        $nazwisko = $_POST['nazwisko'];
        $nr_albumu = $_POST['nr_albumu'];
        $rok_studiow = $_POST['rok_studiow'];
        $miejscowosc = $_POST['miejscowosc'];
        $wojewodztwo = $_POST['wojewodztwo'];
        $rok_urodzenia = $_POST['rok_urodzenia'];
        $status = $_POST['status'];
        $wydzial = $_POST['wydzial'];
        $kierunek = $_POST['kierunek'];

        if(empty($imie)) $errors[] = 'Pole imię jest wymagane';
        if(empty($nazwisko)) $errors[] = 'Pole nazwisko jest wymagane';
        if(empty($nr_albumu)) $errors[] = 'Pole nr albumu jest wymagane';
        if(empty($rok_studiow)) $errors[] = 'Pole rok studiow jest wymagane';
        if(empty($miejscowosc)) $errors[] = 'Pole miejscowosc jest wymagane';
        if(empty($wojewodztwo)) $errors[] = 'Pole wojewodztwo jest wymagane';
        if(empty($rok_urodzenia)) $errors[] = 'Pole rok urodzenia jest wymagane';
        if(empty($status)) $errors[] = 'Pole status jest wymagane';
        if(empty($wydzial)) $errors[] = 'Pole wydzial jest wymagane';
        if(empty($kierunek)) $errors[] = 'Pole kierunek jest wymagane';

        if(empty($errors)){
            //$query = "INSERT INTO `student` (`imie`, `nazwisko`, `nr_albumu`, `rok_studiow`, `miejscowosc`, `wojewodztwo`, `rok_urodzenia`, `status`, `id_wydzial`, `id_kierunek`) VALUES ('$imie', '$nazwisko', '$nr_albumu', '$rok_studiow', '$miejscowosc', '$wojewodztwo', '$rok_urodzenia', '$status', '$wydzial', '$kierunek');";
            $query = "";
            $result = $conn->query($query);
            if($result === TRUE){
                $conn->close();
                header("refresh:0,url=index.php"); 
            }else{
                echo "Coś poszło nie tak";
                $conn->close();
                header("refresh:5,url=index.php");
            }
            exit();
        }else{
            foreach($errors as $error){
                echo "<p> $error </p>";
            }
            echo "<p>Cofnij do strony formularza i popraw błędy!</p>";
            $conn->close();
            exit();
        }

    }else{
        if(!isset($_GET['id'])){
            echo "<h1>Nie podano id użytkownika</h1>";
            $conn->close();
            exit();
        }
        $id = $_GET['id'];
        $query = "SELECT * FROM student WHERE id_student=$id";
        $result = $conn->query($query);
        if($result->num_rows != 1){
            echo "<h1>Błąd w zapytaniu do bazy danych</h1>";
            $conn->close();
            exit();
        }
        while($row = $result->fetch_object()){
            $user = $row;
        }

        $query = "SELECT * FROM wydzial";
        $wydzial = $conn->query($query);

        $query = "SELECT k.id_kierunek, k.nazwa, w.nazwa as wnazwa FROM kierunek as k INNER JOIN wydzial as w ON k.id_wydzial = w.id_wydzial ORDER BY k.id_wydzial";
        $kierunek = $conn->query($query);
    } 
    
    $conn->close();
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dodawanie użytkownika</title>
</head>
<body>
    <h1>Edycja użytkownika - <?php echo $user->imie.' '.$user->nazwisko; ?></h1>
    <form action="" method="post">
        <input type="hidden" name="id_student" value="<?php echo $user->id_student; ?>">
        <p>
            <label for="imie">Imię</label>
            <input type="text" name="imie" value="<?php echo $user->imie; ?>">
        </p>
        <p>
            <label for="nazwisko">Nazwisko</label>
            <input type="text" name="nazwisko" value="<?php echo $user->nazwisko; ?>">
        </p>
        <p>
            <label for="nr_albumu">Numer albumu</label>
            <input type="text" name="nr_albumu" value="<?php echo $user->nr_albumu; ?>">
        </p>
        <p>
            <label for="rok_studiow">Rok studiów</label>
            <input type="number" name="rok_studiow" min="1" max="5" value="<?php echo $user->rok_studiow; ?>">
        </p>
        <p>
            <label for="miejscowosc">Miejscowość</label>
            <input type="text" name="miejscowosc" value="<?php echo $user->miejscowosc; ?>">
        </p>
        <p>
            <label for="wojewodztwo">Województwo</label>
            <input type="text" name="wojewodztwo" value="<?php echo $user->wojewodztwo; ?>">
        </p>
        <p>
            <label for="rok_urodzenia">Rok urodzenia</label>
            <input type="number" name="rok_urodzenia" min="1920" max="<?php echo date('Y')-16; ?>" value="<?php echo $user->rok_urodzenia; ?>">
        </p>
        <p>
            <label for="status">Status</label>
            <select name="status">
                <?php 
                    $status_arr = ['student', 'urlop', 'skreślony', 'absolwent'];
                    $selected = "";
                    foreach($status_arr as $row){
                        if($user->status == $row){
                            $selected = "selected";
                        }else{
                            $selected = "";
                        }
                        echo "<option value='$row' $selected>$row</option>";
                    }
                ?>
            </select>
        </p>

        <p>
            <label for="wydzial">Wydział</label>
            <select name="wydzial">       
                <?php
                    $selected = ""; 
                    while($row = $wydzial->fetch_object()){
                        if($user->id_wydzial == $row->id_wydzial){
                            $selected = "selected";
                        }else{
                            $selected = "";
                        }
                        echo "<option value='$row->id_wydzial' $selected>$row->nazwa</option>";
                    }
                ?>
            </select>
        </p>

        <p>
            <label for="kierunek">Kierunek</label>
            <select name="kierunek">       
                <?php 
                    $selected = "";
                    while($row = $kierunek->fetch_object()){
                        if($user->id_kierunek == $row->id_kierunek){
                            $selected = "selected";
                        }else{
                            $selected = "";
                        }
                        echo "<option value='$row->id_kierunek' $selected>$row->nazwa ($row->wnazwa)</option>";
                    }
                ?>
            </select>
        </p>
        <p>
            <input type="submit" value="Zapisz">
        </p>
    </form>
</body>
</html>