<?php require_once 'dbconnect.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Studia</title>
</head>
<body>
    <a href="dodaj.php">
        <button>Dodaj studenta</button>
    </a>
    <?php 
        $conn = new mysqli($server, $login, $pass, $db);

        $query = "SELECT * FROM student";
        $result = $conn->query($query);

        // while($row = $result->fetch_assoc()){
        //     echo '<p>'.$row['imie'].' '. $row['nazwisko'] .' '. $row['nr_albumu'] .' '. $row['rok_studiow'] .'</p>';
        // }

        // while($row = $result->fetch_object()){
        //     echo '<p>'.$row->imie.' '. $row->nazwisko .' '. $row->nr_albumu .' '. $row->rok_studiow .'</p>';
        // }

        while($row = $result->fetch_row()){
            echo '<p><a href="karta.php?id='.$row[0].'">'.$row[1].' '. $row[2] .'</a> '. $row[3] .' '. $row[4] .'</p>';
        }
        
        $conn->close();
    
    ?>
</body>
</html>