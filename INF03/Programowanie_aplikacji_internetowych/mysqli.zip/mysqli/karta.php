<?php 
    if(!isset($_GET['id'])){
        echo "<h1>Nie podano id użytkownika</h1>";
        exit();
    }else{
        require_once 'dbconnect.php';
        $conn = new mysqli($server, $login, $pass, $db);
        $id = $_GET['id'];
        $query = "SELECT s.id_student, s.imie, s.nazwisko, s.nr_albumu, s.rok_studiow, s.miejscowosc, s.wojewodztwo, s.rok_urodzenia, s.status, w.nazwa as w_nazwa, k.nazwa as k_nazwa FROM student as s INNER JOIN wydzial as w ON s.id_wydzial = w.id_wydzial INNER JOIN kierunek as k ON s.id_kierunek = k.id_kierunek WHERE s.id_student=$id";
        $result = $conn->query($query);
        if($result->num_rows != 1){
            echo "<h1>Błąd w zapytaniu do bazy danych</h1>";
            $conn->close();
            exit();
        }
        while($row = $result->fetch_object()){
            $user = $row;
        }
        $conn->close();

    }
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Karta studenta <?php echo "$user->imie $user->nazwisko"; ?></title>
</head>
<body>
    <h1>Karta studenta</h1>
    <h2>Imię: <?php echo $user->imie; ?></h2>
    <h2>Nazwisko: <?php echo $user->nazwisko; ?></h2>
    <p>Rok studiów: <?php echo $user->rok_studiow; ?></p>
    <p>Wydzial: <?php echo $user->w_nazwa; ?></p>
    <p>Kierunek: <?php echo $user->k_nazwa; ?></p>
    <p>
        <a href="usun.php?id=<?php echo $user->id_student ?>">Usuń</a> | 
        <a href="edytuj.php?id=<?php echo $user->id_student ?>">Edytuj</a>
    </p>
</body>
</html>