<?php 
    if(!isset($_GET['id'])){
        echo "<h1>Nie podano id użytkownika</h1>";
        exit();
    }else{
        require_once 'dbconnect.php';
        $conn = new mysqli($server, $login, $pass, $db);
        $id = $_GET['id'];
        $query = "SELECT * FROM student WHERE id_student=$id";
        $result = $conn->query($query);
        if($result->num_rows != 1){
            echo "<h1>Błąd w zapytaniu do bazy danych</h1>";
            $conn->close();
            exit();
        }
        while($row = $result->fetch_object()){
            $user = $row;
        }
        $conn->close();

    }
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Karta studenta <?php echo "$user->imie $user->nazwisko"; ?></title>
</head>
<body>
    <h1>Karta studenta</h1>
    <h2>Imię: <?php echo $user->imie?></h2>
    <h2>Nazwisko: <?php echo $user->nazwisko?></h2>
</body>
</html>