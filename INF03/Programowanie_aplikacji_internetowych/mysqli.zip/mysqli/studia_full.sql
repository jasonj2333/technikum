DROP DATABASE IF EXISTS studia;
CREATE DATABASE studia CHARACTER SET utf8 COLLATE utf8_polish_ci;

USE studia;

CREATE TABLE wydzial (
id_wydzial INT NOT NULL auto_increment PRIMARY KEY,
nazwa VARCHAR(150) COLLATE utf8_polish_ci NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

CREATE TABLE kolo_naukowe (
id_kolo_naukowe INT NOT NULL auto_increment PRIMARY KEY,
nazwa VARCHAR(150) COLLATE utf8_polish_ci NOT NULL,
id_wydzial INT NOT NULL,
FOREIGN KEY (id_wydzial)
	REFERENCES wydzial(id_wydzial)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

CREATE TABLE klub_sportowy (
id_klub_sportowy INT NOT NULL auto_increment PRIMARY KEY,
nazwa VARCHAR(150) COLLATE utf8_polish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

CREATE TABLE kierunek (
id_kierunek INT NOT NULL auto_increment,
nazwa VARCHAR(250) COLLATE utf8_polish_ci NOT NULL,
id_student INT NOT NULL,
id_wydzial INT NOT NULL,
PRIMARY KEY(id_kierunek),
FOREIGN KEY(id_wydzial)
	REFERENCES wydzial(id_wydzial)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

CREATE TABLE student (
id_student INT NOT NULL auto_increment PRIMARY KEY,
imie VARCHAR(20) COLLATE utf8_polish_ci NOT NULL,
nazwisko VARCHAR(30) COLLATE utf8_polish_ci NOT NULL,
nr_albumu INT NOT NULL,
rok_studiow INT NOT NULL,
miejscowosc VARCHAR(30) COLLATE utf8_polish_ci NOT NULL,
wojewodztwo VARCHAR(30) COLLATE utf8_polish_ci NOT NULL,
rok_urodzenia INT NOT NULL,
status ENUM('student', 'urlop', 'skreślony', 'absolwent') COLLATE utf8_polish_ci,
id_wydzial INT,
id_kierunek INT,
id_kolo_naukowe INT,
id_klub_sportowy INT,
FOREIGN KEY(id_wydzial)
	REFERENCES wydzial(id_wydzial)
    ON DELETE CASCADE,
FOREIGN KEY(id_kierunek)
	REFERENCES kierunek(id_kierunek)
    ON DELETE CASCADE,
FOREIGN KEY(id_kolo_naukowe)
	REFERENCES kolo_naukowe(id_kolo_naukowe)
    ON DELETE CASCADE,
FOREIGN KEY(id_klub_sportowy)
	REFERENCES klub_sportowy(id_klub_sportowy)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

CREATE TABLE przedmiot (
id_przedmiot INT NOT NULL auto_increment PRIMARY KEY,
nazwa VARCHAR(150) COLLATE utf8_polish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

CREATE TABLE przedmiotstudenta (
id_przedmiot_studenta INT NOT NULL,
id_przedmiot INT NOT NULL,
id_student INT NOT NULL,
FOREIGN KEY(id_przedmiot)
	REFERENCES przedmiot(id_przedmiot)
    ON DELETE CASCADE,
FOREIGN KEY(id_student)
	REFERENCES student(id_student)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

INSERT INTO `wydzial` (`id_wydzial`, `nazwa`) VALUES
(1, 'Wydział Informatyki'),
(2, 'Wydział Fizyki i Informatyki Stosowanej'),
(3, 'Wydział Zarządzania'),
(4, 'Wydział Matematyki Stosowanej');

INSERT INTO `kolo_naukowe` (`id_kolo_naukowe`, `nazwa`, `id_wydzial`) VALUES
(1, 'Kosmiczne sprężyny', 1),
(2, 'Odjazdowe roboty',2),
(3, 'Ciepłe bity',2),
(4, 'Szukając prawdy',1);

INSERT INTO `kierunek` (`id_kierunek`, `nazwa`, `id_student`, `id_wydzial`) VALUES
(1, 'Informatyka', 1, 1),
(2, 'Teleinformatyka', 3, 1),
(3, 'Elektronika', 5, 1),
(4, 'Informatyka Stosowana', 6, 2),
(5, 'Fizyka Techniczna', 7, 2),
(6, 'Informatyka i Ekonometria', 8, 3),
(7, 'Zarządzanie', 9, 3),
(8, 'Zarządzanie i Inżynieria Produkcji', 10, 3),
(9, 'Matematyka', 4, 4);

INSERT INTO `klub_sportowy` (`id_klub_sportowy`, `nazwa`) VALUES
(1, 'Koszykówka'),
(2, 'Siatkówka'),
(3, 'Piłka nożna'),
(4, 'Pływanie');

INSERT INTO `student` (`id_student`, `imie`, `nazwisko`, `id_wydzial`, `id_kierunek`, `nr_albumu`, `rok_studiow`, `miejscowosc`, `wojewodztwo`, `rok_urodzenia`, `status`, `id_klub_sportowy`) VALUES
(1, 'Jan', 'Kowalski', 1, 1, 34772, 3, 'Kielce', 'świętokrzyskie', 1999, 'student', 1),
(2, 'Adam', 'Nowak', 2, 4, 34553, 1, 'Kalisz', 'wielkopolskie', 2000, 'student', 2),
(3, 'Michał', 'Szczęsny', 2, 5, 34557, 2, 'Opole', 'opolskie', 1997, 'skreślony', 3),
(4, 'Jakub', 'Przygoński', 3, 8, 34554, 4, 'Kraków', 'małopolskie', 1998, 'urlop', 1),
(5, 'Agnieszka', 'Borówka', 3, 7, 34775, 2, 'Tarnów', 'małopolskie', 1996, 'urlop', 4),
(6, 'Izabela', 'Skała', 3, 6, 34211, 5, 'Krosno', 'podkarpackie', 1995, 'absolwent', 1),
(7, 'Bożena', 'Kralisz', 1, 2, 34675, 1, 'Częstochowa', 'śląskie', 1999, 'student', 2),
(8, 'Damian', 'Izdebski', 2, 4, 34212, 3, 'Katowice', 'śląskie', 1997, 'skreślony', 1),
(9, 'Magdalena', 'Jędraszek', 4, 9, 34222, 4, 'Iława', 'warmińsko-mazurskie', 1997, 'student', 1),
(10, 'Justyna', 'Kędzior', 3, 7, 34556, 1, 'Wrocław', 'dolnośląskie', 2000, 'student', 3);

INSERT INTO `przedmiot` (`id_przedmiot`, `nazwa`) VALUES
(1, 'Matematyka'),
(2, 'Fizyka'),
(3, 'Systemy baz danych'),
(4, 'Programowanie obiektowe');

INSERT INTO `przedmiotstudenta` (`id_przedmiot_studenta`, `id_przedmiot`, `id_student`) VALUES
(1, 1, 1),
(2, 2, 1),
(3, 3, 1),
(4, 4, 1),
(5, 1, 2),
(6, 2, 2),
(7, 3, 2),
(8, 4, 2);