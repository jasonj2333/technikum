<?php 
    require_once 'dbconnect.php';
    $conn = new mysqli($server, $login, $pass, $db);

    if(isset($_POST['imie'])){
        $errors = [];
        $imie = $_POST['imie'];
        $nazwisko = $_POST['nazwisko'];
        $nr_albumu = $_POST['nr_albumu'];
        $rok_studiow = $_POST['rok_studiow'];
        $miejscowosc = $_POST['miejscowosc'];
        $wojewodztwo = $_POST['wojewodztwo'];
        $rok_urodzenia = $_POST['rok_urodzenia'];
        $status = $_POST['status'];
        $wydzial = $_POST['wydzial'];
        $kierunek = $_POST['kierunek'];

        if(empty($imie)) $errors[] = 'Pole imię jest wymagane';
        if(empty($nazwisko)) $errors[] = 'Pole nazwisko jest wymagane';
        if(empty($nr_albumu)) $errors[] = 'Pole nr albumu jest wymagane';
        if(empty($rok_studiow)) $errors[] = 'Pole rok studiow jest wymagane';
        if(empty($miejscowosc)) $errors[] = 'Pole miejscowosc jest wymagane';
        if(empty($wojewodztwo)) $errors[] = 'Pole wojewodztwo jest wymagane';
        if(empty($rok_urodzenia)) $errors[] = 'Pole rok urodzenia jest wymagane';
        if(empty($status)) $errors[] = 'Pole status jest wymagane';
        if(empty($wydzial)) $errors[] = 'Pole wydzial jest wymagane';
        if(empty($kierunek)) $errors[] = 'Pole kierunek jest wymagane';

        if(empty($errors)){
            $query = "INSERT INTO `student` (`imie`, `nazwisko`, `nr_albumu`, `rok_studiow`, `miejscowosc`, `wojewodztwo`, `rok_urodzenia`, `status`, `id_wydzial`, `id_kierunek`) VALUES ('$imie', '$nazwisko', '$nr_albumu', '$rok_studiow', '$miejscowosc', '$wojewodztwo', '$rok_urodzenia', '$status', '$wydzial', '$kierunek');";

            $result = $conn->query($query);
            if($result === TRUE){
                $conn->close();
                header("refresh:0,url=index.php"); 
            }else{
                echo "Coś poszło nie tak";
                $conn->close();
                header("refresh:5,url=index.php");
            }
            exit();
        }else{
            foreach($errors as $error){
                echo "<p> $error </p>";
            }
            echo "<p>Cofnij do strony formularza i popraw błędy!</p>";
            $conn->close();
            exit();
        }

    }else{
        $query = "SELECT * FROM wydzial";
        $wydzial = $conn->query($query);

        $query = "SELECT k.id_kierunek, k.nazwa, w.nazwa as wnazwa FROM kierunek as k INNER JOIN wydzial as w ON k.id_wydzial = w.id_wydzial ORDER BY k.id_wydzial";
        $kierunek = $conn->query($query);
    } 
    
    $conn->close();
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dodawanie użytkownika</title>
</head>
<body>
    <h1>Dodawanie użytkownika</h1>
    <form action="" method="post">
        <p>
            <label for="imie">Imię</label>
            <input type="text" name="imie">
        </p>
        <p>
            <label for="nazwisko">Nazwisko</label>
            <input type="text" name="nazwisko">
        </p>
        <p>
            <label for="nr_albumu">Numer albumu</label>
            <input type="text" name="nr_albumu">
        </p>
        <p>
            <label for="rok_studiow">Rok studiów</label>
            <input type="number" name="rok_studiow" min="1" max="5" value="1">
        </p>
        <p>
            <label for="miejscowosc">Miejscowość</label>
            <input type="text" name="miejscowosc">
        </p>
        <p>
            <label for="wojewodztwo">Województwo</label>
            <input type="text" name="wojewodztwo">
        </p>
        <p>
            <label for="rok_urodzenia">Rok urodzenia</label>
            <input type="number" name="rok_urodzenia" min="1920" max="<?php echo date('Y')-16; ?>" value="<?php echo date('Y')-19; ?>">
        </p>
        <p>
            <label for="status">Status</label>
            <select name="status">
                <option value="student">student</option>
                <option value="urlop">urlop</option>
                <option value="skreślony">skreślony</option>
                <option value="absolwent">absolwent</option>
            </select>
        </p>

        <p>
            <label for="wydzial">Wydział</label>
            <select name="wydzial">       
                <?php 
                    while($row = $wydzial->fetch_object()){
                        echo "<option value='$row->id_wydzial'>$row->nazwa</option>";
                    }
                ?>
            </select>
        </p>

        <p>
            <label for="kierunek">Kierunek</label>
            <select name="kierunek">       
                <?php 
                    while($row = $kierunek->fetch_object()){
                        echo "<option value='$row->id_kierunek'>$row->nazwa ($row->wnazwa)</option>";
                    }
                ?>
            </select>
        </p>
        <p>
            <input type="submit" value="Zapisz">
        </p>
    </form>
</body>
</html>