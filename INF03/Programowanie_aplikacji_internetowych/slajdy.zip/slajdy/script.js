let active = 1;
const prev = document.getElementById('prev');
const next = document.getElementById('next');
const image = document.getElementById('image'); 

function changeImg(name){
    image.src = name  + '.png';
    image.alt = 'Obrazek: ' + name;
}

next.onclick = function(){
    if(active < 5) {
        active++;
    }else{
        active = 1     
    }
    const name = 'slajd' + active;
    changeImg(name);
}

prev.addEventListener("click", function(){
    if(active > 1) {
        active--;
    }else{
        active = 5     
    }
    const name = 'slajd' + active;
    changeImg(name); 
});
