<?php 
    require_once 'dbconnect.php';
    $conn = new mysqli($server, $login, $pass, $db);
    
    $query = "SELECT * FROM wydzial";
    $wydzial = $conn->query($query);

    $query = "SELECT * FROM kierunek";
    $kierunek = $conn->query($query);
    
    $conn->close();
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dodawanie użytkownika</title>
</head>
<body>
    <h1>Dodawanie użytkownika</h1>
    <form action="" method="post">
        <p>
            <label for="imie">Imię</label>
            <input type="text" name="imie">
        </p>
        <p>
            <label for="nazwisko">Nazwisko</label>
            <input type="text" name="nazwisko">
        </p>
        <p>
            <label for="nr_albumu">Numer albumu</label>
            <input type="text" name="nr_albumu">
        </p>
        <p>
            <label for="rok_studiow">Rok studiów</label>
            <input type="number" name="rok_studiow" min="1" max="5" value="1">
        </p>
        <p>
            <label for="miejscowosc">Miejscowość</label>
            <input type="text" name="miejscowosc">
        </p>
        <p>
            <label for="wojewodztwo">Województwo</label>
            <input type="text" name="wojewodztwo">
        </p>
        <p>
            <label for="rok_urodzenia">Rok urodzenia</label>
            <input type="number" name="rok_urodzenia" min="1920" max="<?php echo date('Y')-16; ?>" value="<?php echo date('Y')-19; ?>">
        </p>
        <p>
            <label for="status">Status</label>
            <select name="status">
                <option value="student">student</option>
                <option value="urlop">urlop</option>
                <option value="skreślony">skreślony</option>
                <option value="absolwent">absolwent</option>
            </select>
        </p>

        <p>
            <label for="wydzial">Wydział</label>
            <select name="wydzial">       
                <?php 
                    while($row = $wydzial->fetch_object()){
                        echo "<option value='$row->id_wydzial'>$row->nazwa</option>";
                    }
                ?>
            </select>
        </p>
    </form>
</body>
</html>