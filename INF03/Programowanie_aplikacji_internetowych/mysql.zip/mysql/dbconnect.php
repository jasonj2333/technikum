<?php
    $server = "localhost";
    $login = "root";
    $pass = "";
    $db = "studia";
