<?php 
    if(!isset($_GET['id'])){
        echo "<h1>Nie podano id użytkownika</h1>";
        exit();
    }else{
        require_once 'dbconnect.php';
        $conn = new mysqli($server, $login, $pass, $db);
        $id = $_GET['id'];
        $query = "DELETE FROM student WHERE id_student=$id";
        $result = $conn->query($query);
        if($result == TRUE){
            echo "<h1>Usunięto użytkownika</h1>";
        }else{
            echo "<h1>Coś poszło nie tak!</h1>";
        }
        $conn->close();

    }
    header("refresh:5;url=index.php");
?>