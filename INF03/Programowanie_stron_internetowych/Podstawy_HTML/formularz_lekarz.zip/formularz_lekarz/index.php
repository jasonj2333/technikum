<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rejestracja</title>
    <style>
        main{
            margin: 20px 30px;
        }
    </style>
</head>
<body>
    <main>
        <!-- Utwórz formularz rejestracyjny do lekarza z polami:
        - imie
        - nazwisko
        - email
        - data wizyty
        - liczba osób na wizycie
        - zgoda na przetwarzanie danych osobowych
        - przyciski wyczyść i prześlij -->
    </main>  
</body>
</html>