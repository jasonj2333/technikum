function pokaz(id) {
    kontener = document.getElementById(id);
    kontener.style.display = "block";
}

function ukryj(id) {
    kontener = document.getElementById(id);
    kontener.style.display = "none";
}

function powieksz(id){
    kontener = document.getElementById(id);
    kontener.style.width = "100%";
}

function zmniejsz(id){
    kontener = document.getElementById(id);
    kontener.style.width = "50%";
}