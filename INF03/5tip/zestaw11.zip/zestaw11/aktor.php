<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Informacje o aktorze | KinoTEKA</title>
    <link rel="stylesheet" href="styl.css">
</head>
<body>
    <section id="naglowki">
        <header>
            <h2><a href="index.php">KinoTEKA</a></h2>
        </header>
        <header>
            <p><em>W naszej bazie znajdują się najlepsi aktorzy</em></p>
        </header>
    </section>
    <main>
        <section id="aktorzy_a">
            <!-- skrypt2 -->
             <?php 
             if(isset($_GET['id'])){
                $conn = mysqli_connect("localhost", "root", "", "kino");
                $id = $_GET['id'];
                $query = "SELECT `imie`, `nazwisko`, `plik_awatara` FROM `aktorzy` WHERE `id_aktora` = $id;";
                $result  = mysqli_query($conn, $query);
                $row = mysqli_fetch_object($result);
                    
                    echo "<div>";
                    echo "<img src='./pliki17/img/$row->plik_awatara' alt='$row->imie $row->nazwisko' title='$row->imie $row->nazwisko'>";
                    echo "<h1>$row->imie $row->nazwisko</h1>";
                    echo "</div>";

                // skrypt3
                $query = "SELECT f.`id_filmu`, `tytul`, `rok_produkcji` FROM filmy f JOIN filmy_aktorzy fa ON f.id_filmu = fa.id_filmu WHERE fa.id_aktora = $id;";
                $result  = mysqli_query($conn, $query);
                $films_counter = mysqli_num_rows($result);
                if($films_counter === 0){
                     echo "$row->imie nie znajduje się na listach obsady znanych nam produkcji";
                }else{
                   echo "$row->imie znajduje się na listach obsady $films_counter znanych nam produkcji"; 
                }
                

                mysqli_close($conn);
             }
                
             ?>
        </section>

        
    </main>
    <footer>
        <p><strong>Autor: 11122233344</strong></p>
    </footer>
</body>
</html>