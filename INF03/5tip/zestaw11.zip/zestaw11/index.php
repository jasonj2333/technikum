<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista aktorów | KinoTEKA</title>
    <link rel="stylesheet" href="styl.css">
</head>
<body>
    <section id="naglowki">
        <header>
            <h2><a href="index.php">KinoTEKA</a></h2>
        </header>
        <header>
            <p><em>W naszej bazie znajdują się najlepsi aktorzy</em></p>
        </header>
    </section>
    <main>
        <h1>Najlepsi aktorzy tylko w naszym kinie</h1>
        <section id="aktorzy_i">
            <!-- skrypt1 -->
             <?php 
                $conn = mysqli_connect("localhost", "root", "", "kino");
                $query = "SELECT * FROM `aktorzy` ORDER BY `nazwisko`, `imie`;";
                $result  = mysqli_query($conn, $query);
                while($row = mysqli_fetch_object($result)){
                    echo "<a href='aktor.php?id=$row->id_aktora'>";
                    echo "<div>";
                    echo "<img src='./pliki17/img/$row->plik_awatara' alt='$row->imie $row->nazwisko' title='$row->imie $row->nazwisko'>";
                    echo "<p>$row->imie $row->nazwisko</p>";
                    echo "</div>";
                    echo "</a>";
                }
                mysqli_close($conn);
             ?>
        </section>
    </main>
    <footer>
        <p><strong>Autor: 11122233344</strong></p>
    </footer>
</body>
</html>