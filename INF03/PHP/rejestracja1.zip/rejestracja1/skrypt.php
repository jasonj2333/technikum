<?php
    if(!isset($_POST['imie'])) die('Przejdź do strony formularza');
    
    echo"<pre>";
    var_dump($_POST);
    echo"</pre>";

    $name = trim($_POST['imie']);   
    $surname = trim($_POST['nazwisko']);    
    $profession = trim($_POST['zawod']);    
    $email = trim($_POST['email']);    
    $education = $_POST['wyksztalcenie'];    

