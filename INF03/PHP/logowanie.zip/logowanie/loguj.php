<?php 
    session_start();

    if(isset($_SESSION['log'])){
        header('location: index.php');
        exit;
    } elseif(isset($_POST['nazwa']) && isset($_POST['haslo'])){
        if($_POST['nazwa'] == 'janek' && $_POST['haslo'] == 'jan23'){
            $_SESSION['log'] = $_POST['nazwa'];
            header('location: index.php');
            exit;
        }else{
            echo "<p>Nieprawidłowe dane logowania</p>";
        }
    }

?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logowanie</title>
</head>
<body>
    <form action="" method="post">
        <p>Logowanie użytkownika</p>
        <p>Nazwa użytkownika <br><input type="text" name="nazwa"></p>
        <p>Hasło <br><input type="password" name="haslo"></p>
        <p><input type="submit" value="Zaloguj"></p>
    </form>
</body>
</html>