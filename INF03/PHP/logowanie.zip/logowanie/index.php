<?php 
    session_start();

    if(!isset($_SESSION['log'])){
        header('location: loguj.php');
        exit;
    }

    $imie = $_SESSION['log'];
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Strona główna</title>
</head>
<body>
    <h1>Witaj <?php echo $imie; ?></h1>
    <p>Przed opuszczeniem strony <a href="wyloguj.php">wyloguj się!</a></p>
</body>
</html>