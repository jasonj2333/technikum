<?php
    include './includes/class-autoloader.inc.php';
    // include './classes/dbh.class.php';
    // include './classes/denstist.class.php';
    $id = $_GET['id'];
    $dentist = new Dentist();
    $visit = $dentist->getSingleVisit($id);
    if(!$visit){
        header("location: ./index.php");
    }
?>
<?php require_once 'header.php'; ?>
    <!-- Main Start -->
    <div class="container-fluid py-5 wow fadeInUp" data-wow-delay="0.1s">
        <div class="container">
            <div class="row g-5 mb-5">
                <div class="col-lg-12">
                    <div class="section-title mb-4">
                        <h5 class="position-relative d-inline-block text-primary text-uppercase">Wizyta</h5>
                    </div>


                    <div class="row g-3">
                        <h1> <?php echo $visit['imie'] .' '. $visit['nazwisko']?> </h1>


                            <form action="./includes/visitEdit.php" method="post">
                            <input type="hidden" name="id" value="<?php echo $visit['id'] ?>" >
                                <div class="row">
                                    <div class="col">
                                        <label for="dataWizyty">Data wizyty</label>
                                        <input name="dataWizyty" type="text" class="form-control" placeholder="Data wizyty" value="<?php echo $visit['dataWizyty'] ?>">
                                    </div>
                                    <div class="col">
                                        <label for="godzinaWizyty">Godzina wizyty</label>
                                        <input name="godzinaWizyty" type="text" class="form-control" placeholder="Godzina wizyty" value="<?php echo $visit['godzinaWizyty'] ?>">
                                    </div>
                                </div>

                                <div class="row mt-2">
                                    <div class="col">
                                        <label for="rodzajWizyty">Zabieg</label>
                                        <input name="rodzajWizyty" type="text" class="form-control" placeholder="Rodzaj wizyty" value="<?php echo $visit['rodzajWizyty'] ?>">
                                    </div>
                                    <div class="col">
                                        <label for="zab">Ząb</label>
                                        <input name="zab" type="text" class="form-control" placeholder="Ząb" value="<?php echo $visit['zab'] ?>">
                                    </div>
                                    <div class="col">
                                        <label for="kosztWizyty">Koszt</label>
                                        <input name="kosztWizyty" type="text" class="form-control" placeholder="Koszt Wizyty" value="<?php echo $visit['kosztWizyty'] ?>">
                                    </div>
                                </div>
                                <div class="row mt-2">
                                    <div class="col">
                                    <button type="submit" class="btn btn-primary">Zapisz</button>
                                    </div>
                                </div>
                            </form>

                    </div>    

                </div>

            </div>


        </div>
    </div>
    <!-- Main End -->

    

<?php require_once 'footer.php'; ?>
</body>

</html>