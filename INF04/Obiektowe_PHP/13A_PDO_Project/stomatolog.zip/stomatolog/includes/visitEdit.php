<?php
include './class-autoloader.inc.php';
// include '../classes/dbh.class.php';
// include '../classes/weather.class.php';

if(isset($_POST['id'])){
        $id = $_POST['id'];
        $dataWizyty = $_POST['dataWizyty'];
        $godzinaWizyty = $_POST['godzinaWizyty'];
        $rodzajWizyty = $_POST['rodzajWizyty'];
        $zab = $_POST['zab'];
        $kosztWizyty = $_POST['kosztWizyty'];

        try {
            $visit = new Dentist();
            $visit->editVisit($id, $dataWizyty, $godzinaWizyty, $rodzajWizyty, $zab, $kosztWizyty);
            header("location: ../visit.php?id=".$id);
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
}
