
    <h1>Tablica ogłoszeń</h1>

    <?php foreach($data_view as $row) : ?>
        <div class="card mt-2">
            <div class="card-header">
                <h3><?php echo $row['title'] ?></h3>
                <p><?php echo $row['create_date'] ?></p>
            </div>
            <div class="card-body">
                <p class="card-text"><?php echo $row['content'] ?></p>
            </div>
            <?php if(!empty($_SESSION['user_data']) && $row['user_id'] == $_SESSION['user_data']['id']): ?>
                <div class="card-footer">
                    <a href="">Usuń</a>
                    <a href="">Edytuj</a>
                </div>
            <?php endif; ?>


        </div>
        
        
    <?php endforeach; ?>
