<?php
class AdsController extends Controller{


    public function Index()
    {
        $model = new Ad();
        $data = $model->Index();
        $this->returnView('ads/index', $data);
    }

    public function Delete($id=null)
    {
        echo "Users controller - delete $id";
    }
}