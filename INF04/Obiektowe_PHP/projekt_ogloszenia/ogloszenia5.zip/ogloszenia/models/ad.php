<?php
class Ad extends Model{
    public function Index()
    {
        # code...
    }
}

    