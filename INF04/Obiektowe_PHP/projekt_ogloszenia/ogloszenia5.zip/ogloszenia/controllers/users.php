<?php
class UsersController extends Controller{


    public function Index()
    {
        echo "Users controller";
    }

    public function Delete($id=null)
    {
        echo "Users controller - delete $id";
    }
}