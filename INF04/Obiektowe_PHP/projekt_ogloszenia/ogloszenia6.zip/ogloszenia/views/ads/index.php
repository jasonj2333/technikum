
    Ads Controller - Index

    <?php foreach($data_view as $row) : ?>
        <h3><?php echo $row['title'] ?></h3>
        <p><?php echo $row['create_date'] ?></p>
        <p><?php echo $row['content'] ?></p>
    <?php endforeach; ?>
