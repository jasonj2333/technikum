<?php

class HomeController{
    public function Index()
    {
        echo "Home controller";
    }
}