<?php

class HomeController extends Controller{
    public function Index()
    {
        $this->returnView('home/home');
    }
}