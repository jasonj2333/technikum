<?php
class AdsController extends Controller{


    public function Index()
    {
        $this->returnView('ads/index');
    }

    public function Delete($id=null)
    {
        echo "Users controller - delete $id";
    }
}