@extends('layout.app')

@section('title', 'Witaj na mojej stronie')

@section('content')
    <h1>Strona główna</h1>
@endsection