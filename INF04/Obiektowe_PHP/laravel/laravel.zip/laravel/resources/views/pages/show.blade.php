@extends('layout.app')

@section('title', $title)

@section('content')
    <h1>Strona {{ $title }}</h1>
@endsection