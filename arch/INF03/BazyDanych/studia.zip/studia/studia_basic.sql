-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Czas generowania: 01 Paź 2018, 13:48
-- Wersja serwera: 10.1.34-MariaDB
-- Wersja PHP: 7.2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Baza danych: `studia`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `kierunek`
--

CREATE TABLE `kierunek` (
  `id_kierunek` int(11) NOT NULL,
  `nazwa` varchar(250) COLLATE utf8_polish_ci NOT NULL,
  `id_wydzial` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Zrzut danych tabeli `kierunek`
--

INSERT INTO `kierunek` (`id_kierunek`, `nazwa`, `id_wydzial`) VALUES
(1, 'Informatyka', 1),
(2, 'Teleinformatyka', 1),
(3, 'Elektronika', 1),
(4, 'Informatyka Stosowana', 2),
(5, 'Fizyka Techniczna', 2),
(6, 'Informatyka i Ekonometria', 3),
(7, 'Zarządzanie', 3),
(8, 'Zarządzanie i Inżynieria Produkcji', 3),
(9, 'Matematyka', 4);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `student`
--

CREATE TABLE `student` (
  `id_student` int(11) NOT NULL,
  `imie` varchar(20) COLLATE utf8_polish_ci NOT NULL,
  `nazwisko` varchar(30) COLLATE utf8_polish_ci NOT NULL,
  `id_wydzial` int(11) NOT NULL,
  `id_kierunek` int(11) NOT NULL,
  `nr_albumu` int(11) NOT NULL,
  `rok_studiów` int(11) NOT NULL,
  `miejscowosc` varchar(30) COLLATE utf8_polish_ci NOT NULL,
  `wojewodztwo` varchar(30) COLLATE utf8_polish_ci NOT NULL,
  `rok_urodzenia` int(11) NOT NULL,
  `status` enum('student','urlop','skreslony','absolwent') COLLATE utf8_polish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Zrzut danych tabeli `student`
--

INSERT INTO `student` (`id_student`, `imie`, `nazwisko`, `id_wydzial`, `id_kierunek`, `nr_albumu`, `rok_studiów`, `miejscowosc`, `wojewodztwo`, `rok_urodzenia`, `status`) VALUES
(1, 'Jan', 'Kowalski', 1, 1, 34772, 3, 'Kielce', 'świętokrzyskie', 1999, 'student'),
(2, 'Adam', 'Nowak', 2, 4, 34553, 1, 'Kalisz', 'wielkopolskie', 2000, 'student'),
(3, 'Michał', 'Szczęsny', 2, 5, 34557, 2, 'Opole', 'opolskie', 1997, 'skreslony'),
(4, 'Jakub', 'Przygoński', 3, 8, 34554, 4, 'Kraków', 'małopolskie', 1998, 'urlop'),
(5, 'Agnieszka', 'Borówka', 3, 7, 34775, 2, 'Tarnów', 'małopolskie', 1996, 'urlop'),
(6, 'Izabela', 'Skała', 3, 6, 34211, 5, 'Krosno', 'podkarpackie', 1995, 'absolwent'),
(7, 'Bożena', 'Kralisz', 1, 2, 34675, 1, 'Częstochowa', 'śląskie', 1999, 'student'),
(8, 'Damian', 'Izdebski', 2, 4, 34212, 3, 'Katowice', 'śląskie', 1997, 'skreslony'),
(9, 'Magdalena', 'Jędraszek', 4, 9, 34222, 4, 'Iława', 'warmińsko-mazurskie', 1997, 'student'),
(10, 'Justyna', 'Kędzior', 3, 7, 34556, 1, 'Wrocław', 'dolnośląskie', 2000, 'student');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `wydzial`
--

CREATE TABLE `wydzial` (
  `id_wydzial` int(11) NOT NULL,
  `nazwa` varchar(150) COLLATE utf8_polish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Zrzut danych tabeli `wydzial`
--

INSERT INTO `wydzial` (`id_wydzial`, `nazwa`) VALUES
(1, 'Wydział Informatyki'),
(2, 'Wydział Fizyki i Informatyki Stosowanej'),
(3, 'Wydział Zarządzania'),
(4, 'Wydział Matematyki Stosowanej');

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `kierunek`
--
ALTER TABLE `kierunek`
  ADD PRIMARY KEY (`id_kierunek`);

--
-- Indeksy dla tabeli `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id_student`);

--
-- Indeksy dla tabeli `wydzial`
--
ALTER TABLE `wydzial`
  ADD PRIMARY KEY (`id_wydzial`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT dla tabeli `kierunek`
--
ALTER TABLE `kierunek`
  MODIFY `id_kierunek` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT dla tabeli `student`
--
ALTER TABLE `student`
  MODIFY `id_student` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT dla tabeli `wydzial`
--
ALTER TABLE `wydzial`
  MODIFY `id_wydzial` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
