CREATE TABLE stopien_tytul(
    id_stopien int AUTO_INCREMENT PRIMARY KEY,
    nazwa varchar(30) NOT NULL
);

CREATE TABLE pracownik(
    id_pracownik int AUTO_INCREMENT PRIMARY KEY,
    imie varchar(30) NOT NULL,
    nazwisko varchar(50) NOT NULL,
    id_stopien_tytul int NOT NULL,
    FOREIGN KEY (id_stopien_tytul) REFERENCES stopien_tytul(id_stopien) ON DELETE CASCADE,
    dziekan int,
    id_wydzial int NOT NULL,
    FOREIGN KEY (id_wydzial) REFERENCES wydzial(id_wydzial) ON DELETE CASCADE
);
-- Późniejsze dodanie kluczy obcych
-- ALTER TABLE pracownik 
--     add constraint fk_id_stopien_tytul
--     FOREIGN KEY (id_stopien_tytul) REFERENCES stopien_tytul(id_stopien) ON DELETE CASCADE;

-- ALTER TABLE pracownik 
-- add constraint fk_id_wydzial
--     FOREIGN KEY (id_wydzial) REFERENCES wydzial(id_wydzial) ON DELETE CASCADE;

INSERT INTO stopien_tytul VALUES
(1, 'inż.'),
(2, 'mgr'),
(3, 'mgr inż.'),
(4, 'dr'),
(5, 'dr inż.'),
(6, 'dr hab.'),
(7, 'dr hab. inż.'),
(8, 'prof.');

INSERT INTO pracownik VALUES
(1, 'Jakub', 'Ostrowski', 8, 1, 1),
(2, 'Damian', 'Nowak', 8, NULL, 1),
(3, 'Grzegorz', 'Cebula', 7, NULL, 1),
(4, 'Justyna', 'Kowalska', 5, NULL, 1),
(5, 'Joanna', 'Stawowy', 2, NULL, 1),
(6, 'Sebastian', 'Wilk', 4, NULL, 1),
(7, 'Aleksandra', 'Zasada', 3, NULL, 1);