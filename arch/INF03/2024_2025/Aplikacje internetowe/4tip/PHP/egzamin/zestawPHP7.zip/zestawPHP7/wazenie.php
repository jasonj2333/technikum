<!DOCTYPE html>
<html lang="pl">

<head>
    <meta charset="UTF-8">
    <title>Ważenie samochodów ciężarowych</title>
    <link rel="stylesheet" href="styl.css">
</head>

<?php
header("refresh: 10;");
?>

<body>
    <header>
        <section id="banner1">
            <h1>Ważenie pojazdów we Wrocławiu</h1>
        </section>
        <section id="banner2">
            <img src="obraz1.png" alt="waga">
        </section>
    </header>
    <main>
        <section id="lewy">
            <h2>Lokalizacje wag</h2>
            <ol>
                <!-- skrypt -->
            </ol>
            <h2>Kontakt</h2>
            <a href="mailto:wazenie@wroclaw.pl">napisz</a>
        </section>
        <section id="srodkowy">
            <h2>Alerty</h2>
            <table>
                <tr>
                    <th>rejestracja</th>
                    <th>ulica</th>
                    <th>waga</th>
                    <th>dzień</th>
                    <th>czas</th>
                </tr>
                <!-- skrypt -->
            </table>
            <!-- skrypt -->
        </section>
        <section id="prawy">
            <img src="obraz2.jpg" alt="tir">
        </section>
    </main>
    <footer>
        <p>Stronę wykonał: 112121231231231</p>
    </footer>
</body>

</html>