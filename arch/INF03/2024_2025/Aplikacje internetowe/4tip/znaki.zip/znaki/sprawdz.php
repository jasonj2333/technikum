<?php
    $odpowiedzi = $_POST;
    $conn = mysqli_connect("localhost", "root", "", "ja_znaki");
    $punkty = 0;
    foreach($odpowiedzi as $key=>$value){
        $query = "SELECT id FROM baza_znakow WHERE id=$key AND symbol='$value'";
        $result = mysqli_query($conn, $query);
        if(mysqli_num_rows($result)) $punkty++;
    }

    echo $punkty;
