// document.getElementById("intro");
// document.getElementsByTagName("p");
// document.getElementsByClassName("intro");
// document.getElementsByName("fname");
// document.querySelector(".intro")
// document.querySelectorAll('div')

